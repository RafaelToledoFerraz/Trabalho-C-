#include <iostream>

using namespace std;

int main () {
    int vetor[5];
    int i = 0;
    int soma = 0;

    for(i;i<5;i++){
    cout << "digite o valor " << i+1 << ": ";
    cin >> vetor[i];
    if(vetor[i]%2 !=0){
        soma += vetor[i];
    }
}
cout << "\no valor das somas dos valores impares e de " << soma << ".\n";

    return 0;
}
