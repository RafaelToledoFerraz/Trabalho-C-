#include <iostream>
#include <cmath>

//3 - Para uma determinada avalia��o aplicada, fazer um programa que armazene em um vetor  as notas de 5 alunos.
//Para cada um desses alunos, calcular e armazenar em um vetor o desvio em rela��o a m�dia.
//Em seguida, calcular e armazenar em outro vetor os desvios [em rela��o a m�dia] ao  quadrado das notas de cada aluno.
//Ao final, calcular e apresentar a vari�ncia e o desvio padr�o.

using namespace std;

int main () {
    float vetNotas[5];
    float vetDesvio[5];
    float vetDesviosQuadrados[5];
    float somaNotas = 0.0;
    float Media = 0.0;
    float SomaDesviosQuadrados = 0.0;
    float variancia = 0.0;
    float DesvioPadrao = 0.0;

    for(int i = 0 ; i<5 ; i++) {
        cout << "Informe a nota do aluno " << i+1 << ": ";
        cin >> vetNotas[i];
        somaNotas += vetNotas[i];
    }

    Media = somaNotas/5;

    for(int i = 0 ; i<5 ; i++) {
        vetDesvio[i] = vetNotas[i] - Media;
        vetDesviosQuadrados[i] = pow(vetDesvio[i], 2);
        SomaDesviosQuadrados =+ vetDesviosQuadrados[i];
    }

    variancia = SomaDesviosQuadrados / 5;
    DesvioPadrao = sqrt(variancia);

    cout << "\n\nDesvios em relacao a media: ";
    for(int i = 0 ; i<5 ; i++) {
        cout << "\nAluno " << i+1 << ":" << vetDesvio[i];
    }

    cout << "\n\nDesvios ao quadrado em relacao a media: ";
    for(int i = 0 ; i<5 ; i++) {
        cout << "\nAluno " << i+1 << ":" << vetDesviosQuadrados[i];
    }

    cout << "\n\nVariancia: " << variancia;
    cout << "\n\nDesvio padrao: " << DesvioPadrao;


    cout << "\n\n\n";
 return 0;
}
