#include <iostream>
#include <stdlib.h>

using namespace std;

int main () {

    int vetValor[10];
    int soma = 0;

    cout << "Quais elementos vao ter no programa? \n\n";
    for(int i = 0; i<10;i++){
        cin >> vetValor[i];
        cout << "\n";

        if(i%2 !=0 ) {
            soma += i;
        }
    }
    cout << "A soma dos numeros em posicao impar e de: " << soma << ".\n\n";



   int maiorNumero1, maiorNumero2;

    if (vetValor[0] > vetValor[1]) {
        maiorNumero1 = vetValor[0];
        maiorNumero2 = vetValor[1];
    } else {
        maiorNumero1 = vetValor[1];
        maiorNumero2 = vetValor[0];
    }


    for (int i = 2; i < 10; i++) {
        if (vetValor[i] > maiorNumero1) {
            maiorNumero2 = maiorNumero1;
            maiorNumero1 = vetValor[i];
        } else if (vetValor[i] > maiorNumero2) {
            maiorNumero2 = vetValor[i];
        }
    }

    cout << "Os dois maiores numeros sao: " << maiorNumero1 << " e " << maiorNumero2 << "." << endl;



    return 0;
}
