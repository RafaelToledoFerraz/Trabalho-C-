#include <iostream>
#include <stdlib.h>

//2 - Fa�a um programa que armazene em um vetor de inteiros as quantidades compradas de 5  produtos.
//Em outro vetor de reais, armazene o valor unit�rio de cada produto.
//O programa deve, ao  final, mostrar o valor total a ser pago por cada produto assim como o valor total da compra.
// Considere que o �ndice do vetor corresponde ao c�digo do produto.

using namespace std;

int main () {

    int vetProdutos[5];
    float vetPreco[5];
    float vetTotalProduto[5];
    float valorTotalCompra = 0.0;

    cout << "Ola. Bem vindo.\n";

    for(int i = 0;i<5;i++) {
        cout << "\nDigite a quantidade do produto " << i+1 << " que foi comprada: ";
        cin >> vetProdutos[i];
        cout << "\nInforme o valor unitario do produto " << i+1 << ": ";
        cin >> vetPreco[i];
    }
    for (int i = 0;i<5; i++) {
        vetTotalProduto[i] = vetProdutos[i] * vetPreco[i];
        valorTotalCompra += vetTotalProduto[i];
    }

    cout << "\nValor total por produto:\n";

    for(int i = 0;i<5;i++) {
        cout << "O total do produto " << i+1 << " e de " << vetTotalProduto[i] << " R$\n\n";
    }

    cout << "O valor total da compra e de: " << valorTotalCompra << " R$\n\n";

    cout << "Volte sempre!\n";


 return 0;
}
